import React from 'react'

const Footer = () => {
  return (
    <div style={{
        height: "200px",
        width : "100%",
        backgroundColor : "skyblue",
    }}
    >
      Footer..
    </div>
  )
}

export default Footer
